# Audit — 666 ChatBackup Scriptable iPhone v1.0.0

## Implementation

- Guided Scriptable UI via native Alerts, UITable, WebView and ShareSheet: PASS (source review)
- Default language English / persistent EN-DE selection: PASS (source review)
- Public ChatGPT share workflow: PASS (source review)
- Private/manual clipboard workflow: PASS (source review)
- Manual participant/group parsing with fail-closed behavior: PASS (source review)
- React Flight / __NEXT_DATA__ / WebView fallback paths: PASS (source review)
- Structure browser and per-message structure JSON: PASS (source review)
- Machine JSON schema `666.chatbackup.machine.v1` / 1.3.0: PASS (source review)
- Structure schema `666.chatbackup.structure-inspector.v1` / 1.1.0: PASS (source review)
- Direct image preview/download and bulk reachable-image download: PASS (source review)
- Binary image write/readback length check: PASS (source review)
- No eval for Copy/UI extraction: PASS
- Raw source retention with 12,000,000-char guard: PASS (source review)
- JavaScript syntax: PASS (`node --check`)

## Platform gate

- Real Scriptable/iPhone runtime readback: PENDING
- Real ChatGPT live-share parser readback on iPhone: PENDING

These are intentionally not claimed as PASS because the current build environment is not iOS/Scriptable.
