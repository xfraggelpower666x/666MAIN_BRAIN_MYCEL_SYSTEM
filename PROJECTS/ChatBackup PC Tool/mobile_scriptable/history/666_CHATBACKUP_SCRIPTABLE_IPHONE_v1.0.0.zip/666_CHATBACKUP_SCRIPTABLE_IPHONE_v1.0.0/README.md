# 666 ChatBackup Scriptable iPhone v1.0.0

Native Scriptable companion for the 666 ChatBackup PC Tool line.

## Install

1. Install **Scriptable** from the iOS App Store.
2. Open `666_CHATBACKUP_SCRIPTABLE_IPHONE.js` and copy it into a new Scriptable script.
3. Run the script once. English is the default language.
4. Use **Language** to switch to German. The setting is stored under `iCloud Drive/Scriptable/666_CHATBACKUP_SCRIPTABLE/settings.json`.

## Guided menu

- **Public Share Link** — load and analyze public ChatGPT `/share/` or `/s/` links.
- **Private / Manual Import** — analyze the complete visible transcript from the iPhone clipboard; private `/c/` links are not bypassed.
- **Current Chat / Structure** — browse messages and save/copy per-message structure JSON.
- **Chat Images** — browse detected image assets, preview direct HTTP(S) images, download one or all reachable images as real binary files.
- **Export** — Markdown, JSON, JSONL, JavaScript, Structure JSON, or all formats into a portable iCloud folder.
- **Language** — English / Deutsch, persisted across launches.
- **Help** — bilingual usage guide covering public links, private chats, full-chat recovery, group chats, images and exports.

## Group chat support

Explicit participant IDs/names from structured share data are preserved. Manual transcripts with speaker labels such as `Alice:`, `Bob:` and `ChatGPT:` are reconstructed as separate participants. Unknown identities stay unresolved rather than being guessed.

## Images

Directly reachable images are written as binary image files. Internal ChatGPT asset pointers without public bytes are retained as metadata only. The script does not invent Base64 images.

## Portable export on iPhone

Scriptable has no native ZIP-writing API. The `All Formats + Source Folder` command creates a portable iCloud folder containing machine exports, source receipts, raw source when available, and reachable image files. If a ZIP is needed, compress that folder with the iOS Files app.

## Parser lineage

The mobile parser mirrors the PC v1.8.2 design principles:

- React Flight loader support
- legacy `__NEXT_DATA__`
- rendered WebView fallback
- raw content / metadata preservation where delivered
- Copy/UI-field static analysis without `eval`
- manual transcript analysis
- participant-aware group-chat model
- fail-closed identity handling
- honest integrity states; visual parity is never claimed

## Limits

Private ChatGPT `/c/` pages require the user's authenticated session and are therefore handled through manual clipboard import rather than bypassing login. Dynamic UI bindings, deleted content, inaccessible private asset bytes, and data never delivered by the source cannot be reconstructed.
