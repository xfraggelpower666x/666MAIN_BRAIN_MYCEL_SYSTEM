# 666 ChatBackup Scriptable iPhone v1.0.6

Variant-tolerant Scriptable companion for ChatGPT shared conversations.

## Import architecture

1. Structured React-Flight / legacy source parser
2. Direct raw-HTML SSR transcript parser
3. Fetched-source WebView recovery
4. Live WebView DOM recovery
5. Manual clipboard import

The direct SSR parser recognizes the newer server-rendered transcript family without requiring WebView rendering:

- `data-conversation-transcript`
- `data-message-role="assistant|user"`
- `data-assistant-markdown-root`
- `data-assistant-markdown`
- `data-user-message-copy`
- `data-submit-message-animation-target`

The older React-Flight and legacy DOM paths remain preserved.

## Identity safety

A `data-message-role="user"` marker confirms a human/user role, but it does not prove a real participant identity. If no participant name or ID is delivered, participant resolution remains `UNRESOLVED`. The script does not invent identities.

## Images

Direct HTTP(S) images found in structured data or SSR message markup are retained as downloadable image assets. Internal/non-public asset pointers are not converted into invented Base64 data.

## Diagnostics

Failed imports now record a source fingerprint including React-Flight markers, legacy DOM markers and SSR transcript markers. This makes future ChatGPT share-format changes distinguishable without writing an incomplete backup.

## Runtime gate

Real iPhone/Scriptable runtime readback remains required for final platform PASS. Desktop/static tests do not substitute for that platform gate.
