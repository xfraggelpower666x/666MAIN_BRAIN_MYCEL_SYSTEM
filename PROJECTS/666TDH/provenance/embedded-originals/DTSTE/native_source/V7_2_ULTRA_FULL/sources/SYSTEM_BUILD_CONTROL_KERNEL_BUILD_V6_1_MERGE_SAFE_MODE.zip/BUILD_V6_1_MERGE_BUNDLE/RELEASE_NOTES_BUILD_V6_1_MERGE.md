# RELEASE_NOTES_BUILD_V6_1_MERGE

Created: 2026-04-20
Modified: 2026-04-20
Purpose: Human-readable notes for the V6.1 merge package.

## Included changes
- Added one single operational master file
- Preserved canonical core unchanged
- Preserved structure-clean master unchanged
- Preserved V10.1 appendices unchanged
- Carried forward V6 hardening manifest logic

## Not changed
- No destructive rewrite of the canonical core
- No overwrite of the true final master
- No replacement of exact appendices
