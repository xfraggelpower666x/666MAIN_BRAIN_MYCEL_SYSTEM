# SYSTEM_BUILD_CONTROL_KERNEL — BUILD V6.1 MERGE BUNDLE

Created: 2026-04-20
Modified: 2026-04-20
Purpose: Single-master continuation bundle built non-destructively from the uploaded files and the V6 hardening layer.

## What is new
- Added `SYSTEM_BUILD_CONTROL_KERNEL_V6_1_SINGLE_MASTER_MERGED.md` as one primary continuation file
- Preserved original uploaded files unchanged
- Preserved V6 hardening files unchanged
- Added a fresh V6.1 manifest for this merge bundle

## Intended use order
1. Read `SYSTEM_BUILD_CONTROL_KERNEL_V6_1_SINGLE_MASTER_MERGED.md`
2. Use original files for traceability and recovery
3. Use manifest to validate any future full export claim

## Activation
Preferred explicit trigger:
`BOOT V6.1 MERGE`
