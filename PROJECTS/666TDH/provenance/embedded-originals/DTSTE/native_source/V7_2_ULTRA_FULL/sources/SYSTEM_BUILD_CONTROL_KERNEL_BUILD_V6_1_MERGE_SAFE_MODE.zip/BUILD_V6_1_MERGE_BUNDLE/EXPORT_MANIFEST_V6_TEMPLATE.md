# EXPORT_MANIFEST_V6_TEMPLATE

Created: 2026-04-20
Modified: 2026-04-20
Purpose: Mandatory manifest template for every full export / handoff / release bundle.
Change-Summary:
- Defines required bundle structure
- Introduces size, count, and checksum recording points
- Makes mini-export failure visible before release

## Required bundle classes
- CANONICAL_CORE
- STRUCTURED_MASTER
- MODULE_REGISTER
- EVOLUTION_MAP
- README
- APPENDIX_STANDARD
- APPENDIX_ULTRA
- HARDENING_PATCH
- RELEASE_NOTES

## Required manifest fields
```text
BUNDLE_NAME:
BUNDLE_VERSION:
BUILD_DATE:
BUILD_MODE:
CANONICAL_CORE_FILE:
CANONICAL_CORE_SIZE_BYTES:
TOTAL_FILE_COUNT:
TOTAL_SIZE_BYTES:
MIN_EXPECTED_FILE_COUNT:
MIN_EXPECTED_TOTAL_SIZE_BYTES:
VALIDATION_STATUS:
RELEASE_DECISION:
```

## File inventory table
| Class | Required | Filename | Size Bytes | SHA256 | Status |
|---|---|---|---:|---|---|
| CANONICAL_CORE | yes |  |  |  |  |
| STRUCTURED_MASTER | yes |  |  |  |  |
| MODULE_REGISTER | yes |  |  |  |  |
| EVOLUTION_MAP | yes |  |  |  |  |
| README | yes |  |  |  |  |
| APPENDIX_STANDARD | yes |  |  |  |  |
| APPENDIX_ULTRA | yes |  |  |  |  |
| HARDENING_PATCH | yes |  |  |  |  |
| RELEASE_NOTES | yes |  |  |  |  |

## Release gates
A bundle is NOT releasable when one or more of the following is true:
- total file count is below the declared minimum
- total size is implausibly small for a claimed full build
- canonical core is missing
- manifest table is incomplete
- checksum lines are missing for required files
- validation status is not PASS

## Minimum baseline for this project family
- MIN_EXPECTED_FILE_COUNT = 9
- MIN_EXPECTED_TOTAL_SIZE_BYTES = 200000

Note:
The minimum total size is a release gate, not a quality certificate.
A larger bundle can still be wrong. A smaller bundle claiming to be FULL must be blocked automatically.
