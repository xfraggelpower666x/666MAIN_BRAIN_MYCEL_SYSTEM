# LYVRA TRACK DESIGN — DELTA vs v2.5.1 → v3.0

## Authority change
- `v2.5.1` = **RETIRED_VALID_HISTORY_NOT_RUNTIME_AUTHORITY**.
- `v3.0` = **CURRENT**, published by the current specialist pointer.
- Patch-stack runtime is disabled.
- History remains recovery/learning/provenance evidence, never a vote over Current.

## Architecture change
- Current model is explicitly `RELATIONAL_CAUSAL_EVOLVING`, not template reconstruction.
- LYVRA remains meaning/creative decision authority.
- Track Design is specialized musical execution intelligence.
- Host/GPT is technical execution only.
- Renderer realizes audio and receives resolved consequences rather than LYVRA's full reasoning.

## Musical-physics change
- Primary motor continuity becomes an explicit causal requirement.
- Current main motor: dry short kick + straight relentless rolling 16th psybass + stable bar grid + continuous forward traction.
- Stable BPM alone and stable grid alone are explicitly insufficient.
- Surface, semantic, voice, atmosphere, or section changes must not silently replace locomotion.
- BPM is contextual; no universal/fixed boot BPM survives as Current authority.

## Three-field model
- LOW: physical-temporal pressure / real time / grid / kick-bass phase / traction / pressure direction.
- MID: structured psychedelic movement / Goa / acid / percussion / motifs / voice body / readable space.
- HIGH: perceptual psychoacoustic transformation / spectral / granular / phase / forest / phantom motion / depth / perceived-time distortion.
- All fields interact causally, but authority is not equal and field responsibility persists.

## Output / renderer change
- Current default contract: `LYVRA_6BOX_FULL_v3_0`.
- Six visible codeboxes, ordered TITLE → EXTENDED → STYLE → LYRICS/STRUCTURE → TRACK DNA/PRODUCTION LOGIC → LYVRA AUDIT.
- Boxes 1–4 are Suno payload; Boxes 5–6 are internal.
- Older contradictory four-codebox-default fragments are provenance only.
- Style is no longer a static ingredient list: it carries sonic identity plus primary motion identity.
- Extended develops the already-resolved motor and must not redefine real time or the foundation.

## Emotional / semantic change
- Emotion, intimacy, trust, love, vulnerability and harmony do not automatically imply softness.
- Lyric sentiment is not a production method and may not override resolved physical style.
- Source meaning preservation is required; unrequested sanitization and explicit expansion are forbidden.

## Ending / arrangement change
- No universal ending template.
- No universal arrangement template.
- Hard stop and fade are both non-default.
- Ending is contextually derived; post-final reactivation check is applied when relevant.

## Validation change
- Publication validation now explicitly covers motor identity, section continuity, field responsibility,
  anti-softening, renderer contradiction, source/lyric fidelity, duration and six-box integrity.
- Real-track validation after v3 adoption remains **OPEN** until new rendered tracks are evaluated.

## History kept
v2.5.1 remains valid history, recovery reference and learning reference. Historical concepts not
explicitly reactivated by v3.0 are not silently deleted; they are classified separately as provenance,
unconfirmed current, hold, or superseded.
