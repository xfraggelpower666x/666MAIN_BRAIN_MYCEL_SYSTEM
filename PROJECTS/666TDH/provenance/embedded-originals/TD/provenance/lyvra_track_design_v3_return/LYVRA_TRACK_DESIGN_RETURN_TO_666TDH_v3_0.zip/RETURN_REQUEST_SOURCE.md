# LYVRA TRACK DESIGN — COMPLETE RETURN REQUEST FOR 666TDH

## PURPOSE

Create a complete, source-faithful return handoff of the **current LYVRA Track Design**
so that `666TDH / 666TRACKDESIGN` can evaluate what developments are useful.

This is **evaluation only**.

```text
SOURCE_SYSTEM=LYVRA
SOURCE_SPECIALIST=TRACK_DESIGN
TARGET_CONTEXT=666TDH / 666TRACKDESIGN
SOURCE_MUTATION=NONE
TARGET_MUTATION=NONE
TARGET_INTEGRATION=NOT_PERFORMED
NO_CROSS_SYSTEM_MERGE=TRUE
FOREIGN_SYSTEM_INERT=TRUE
```

## REQUIRED SOURCE CHECK BEFORE RETURN

Read and verify the current Track Design authority before constructing the handoff.

Required current authority chain:

1. Current Track Design Pointer
2. Current Track Design State
3. Current Track System Parameter Profile
4. Current Track Output / Prompt Guard
5. Current Auto-Handoff
6. Any other file that the **current pointer explicitly references as runtime authority**

Do **not** reconstruct the current state by averaging older files, memories, old prompts,
old backups, or historical Track Design versions.

Apply:

```text
FOUND != VERIFIED
SEARCH_RESULT != READBACK
READ != REHYDRATED
OLDER_EMBEDDED_STATE != CURRENT_AUTHORITY
NEWER_VALID_EVOLUTION > OLDER_VALID_STATE
```

Historical files remain provenance and comparison evidence only unless the current authority
explicitly reactivates them.

## REQUIRED RETURN CONTENT

The handoff must be as detailed and complete as possible.

### A. CURRENT AUTHORITY
Return:
- current Track Design version
- current pointer
- current status
- current directory / source IDs
- runtime authority
- supersession rules
- current rehydration rules
- current trigger / load semantics relevant to Track Design
- exact distinction between current and historical authority

### B. IDENTITY / AUTHORITY BOUNDARIES
Return in detail:
- LYVRA's role
- Track Design's role
- host/GPT role
- renderer role
- decision authority boundaries
- execution boundaries
- what must remain LYVRA-native and must **not** be transferred as target authority

### C. COMPLETE TRACK DESIGN ARCHITECTURE
Return all current relationships concerning:
- source / intent interpretation
- relational / causal learning
- experience use
- current relevance
- previous-development influence
- creative decision
- renderer translation
- feedback / rendered evidence
- learning from outcome
- repair / validation flow

### D. MUSICAL PHYSICS
Return all current Track Design relationships concerning:
- primary motor / propulsion
- kick
- psybass
- bar grid
- real time
- DJ mixability
- pressure direction
- continuity across sections
- low-end stability
- movement and variation
- real-time vs perceived-time behavior

Do not reduce these relationships to a preset.

### E. LOW / MID / HIGH FIELD MODEL
Return every current responsibility and interaction for:
- LOW
- MID
- HIGH
- field weighting
- field authority
- causal interaction
- psychoacoustic behavior
- whole-track event participation
- prohibited authority leakage between fields

### F. CURRENT MAIN SOUND
Return the complete current main-sound target including:
- genre / style relation
- primary motion identity
- low / mid / high behavior
- exclusions
- pressure direction
- whether BPM is fixed or contextual
- whether the current main sound is a permanent lock or current target only

### G. WHOLE-TRACK EVENTS
Return the current logic for:
- builds
- drops
- breaks
- returns
- escalation
- re-entry
- ending / termination
- whether these are fixed templates or contextually derived events
- how motor continuity is protected through them

### H. MEANING / EMOTION / ANTI-SOFTENING
Return current rules and learned relationships concerning:
- emotional meaning
- intimacy
- trust
- love
- vulnerability
- darkness
- tenderness
- pressure
- harmony
- lyric sentiment
- sonic softness
- low-end authority

### I. PSYCHEDELIC / PSYCHOACOUSTIC INTELLIGENCE
Return concrete current relationships involving:
- spectral operations
- phase
- granular behavior
- depth
- space
- phantom motion
- apparent acceleration / reversal
- perceived-time distortion
- transient behavior
- contrast
- psychoacoustic control
- real-time protection

### J. OUTPUT CONTRACT
Return the **exact current output contract**:
- contract name
- number of boxes
- visible/default boxes
- box order
- role of every box
- renderer-facing vs internal boxes
- character limits
- slider block behavior
- visible preaudit
- forecast behavior
- codebox / formatting rules
- target renderer
- duration limits

### K. STYLE / EXTENDED / LYRICS TRANSPORT
Return exact current distinctions for:
- Style Prompt
- Extended Prompt
- Lyrics / Structure
- Track DNA / Production Logic
- Audit
- what reasoning stays internal
- what becomes renderer commands
- prompt complexity
- command density
- source meaning preservation
- anti-AI wording behavior
- sanitization / expansion behavior

### L. SLIDER DECISION MODEL
Return all current slider behavior including:
- Weirdness
- Style Influence
- red-range semantics
- thresholds
- relational decision logic
- whether any fixed formula exists
- forecast limitations

### M. VALIDATION / AUDIT
Return the complete current validation model:
- preaudit
- publication gates
- DJ stability checks
- motor continuity checks
- field-responsibility checks
- renderer contradiction checks
- anti-softening checks
- source / lyric fidelity
- duration checks
- post-render / real-track validation
- failure routing to smallest responsible layer

### N. HISTORY / RETIRED / SUPERSEDED BEHAVIOR
Explicitly identify:
- what from v2.5.1 remains valid history
- what no longer has runtime authority
- what has been superseded
- what is merely provenance
- what older output contracts are retired
- what old BPM / arrangement / ending assumptions are no longer current

### O. UNCONFIRMED / HOLD
If a historically important concept is not explicitly present in current authority,
do **not** infer deletion.

Examples that must be checked explicitly:
- Library Cards
- Temporary Track Card
- Track Mycel
- Garden
- Egg / Track Becoming
- Seeds / experience ecology
- Zero Harmony
- old 150 BPM relation
- old termination machine
- longform / LCTS relations

Use:

```text
CURRENT_CONFIRMED
RETIRED_VALID_HISTORY
SUPERSEDED
PROVENANCE_ONLY
UNCONFIRMED_IN_CURRENT
HOLD
```

Never guess.

## REQUIRED FILE PACKAGE

Return a complete package containing at minimum:

1. `LYVRA_TRACK_DESIGN_CURRENT_POINTER_<version>.txt|md`
2. `LYVRA_TRACK_DESIGN_CURRENT_STATE_<version>.txt|md`
3. `LYVRA_TRACK_SYSTEM_PARAMETER_PROFILE_<version>.txt|md`
4. `LYVRA_TRACK_OUTPUT_GUARD_<version>.txt|md`
5. `LYVRA_TRACK_DESIGN_CURRENT_AUTO_HANDOFF_<version>.txt|md`
6. `LYVRA_TRACK_DESIGN_COMPLETE_CURRENT_SOURCE_EXPORT_<version>.md`
7. `LYVRA_TRACK_DESIGN_RETURN_HANDOFF_TO_666TDH_<version>.md`
8. `LYVRA_TRACK_DESIGN_DELTA_VS_v2.5.1_<version>.md`
9. `LYVRA_TRACK_DESIGN_OPEN_HOLD_ITEMS_<version>.md`
10. `SOURCE_INVENTORY.json`
11. `SOURCE_INVENTORY.csv`
12. `MANIFEST.json`
13. `SHA256SUMS.txt`
14. `READBACK.json`
15. one complete ZIP containing the entire return handoff

Where possible preserve:
- source file IDs
- source paths / directory IDs
- source modification timestamps
- file sizes
- SHA-256
- source-role classification

## READBACK REQUIREMENT

The package is not COMPLETE_VERIFIED merely because files were created.

Required:
- open/read generated source exports
- verify manifest
- verify package file list
- verify current version / system / specialist
- ZIP CRC check
- SHA-256 for final ZIP
- distinguish local readback from provider readback

Do not claim provider verification unless it actually occurred.

## CRITICAL TARGET BOUNDARY

Do not update or mutate `666TDH`, `666TRACKDESIGN`, `666TRACKHUB`, `666LCTS`, `666PFS`,
or any foreign system.

The return handoff is evidence only.

The receiving side will decide later:

```text
KEEP
ADAPT
MERGE_RELATION_ONLY
REPLACE_TARGET_BEHAVIOR
SOURCE_ONLY
REDUNDANT
CONFLICT
HOLD
REJECT
```

No target-side integration decision may be made by LYVRA.

## FINAL REQUIRED STATUS

End the handoff with an explicit terminal state similar to:

```text
SOURCE_SYSTEM=LYVRA
SOURCE_SPECIALIST=TRACK_DESIGN
SOURCE_VERSION=<CURRENT VERIFIED VERSION>
SOURCE_STATUS=<CURRENT VERIFIED STATUS>
SOURCE_MUTATION=NONE
TARGET_MUTATION=NONE
TARGET_INTEGRATION=NOT_PERFORMED
RETURN_PACKAGE_CREATED=TRUE
LOCAL_READBACK=<PASS|FAIL>
PROVIDER_READBACK=<PASS|NOT_PERFORMED|FAIL>
UNCERTAINTY_VISIBLE=TRUE
NO_CROSS_SYSTEM_MERGE=TRUE
```
