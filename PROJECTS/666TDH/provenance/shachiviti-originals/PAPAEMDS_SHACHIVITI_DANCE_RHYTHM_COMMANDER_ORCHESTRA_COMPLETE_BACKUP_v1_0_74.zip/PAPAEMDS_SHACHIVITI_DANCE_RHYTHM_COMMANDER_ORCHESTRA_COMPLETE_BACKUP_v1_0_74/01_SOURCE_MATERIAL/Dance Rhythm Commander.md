[Intro]
Attention all districts. This is a sonic takeover.
Execute the order.
Move!
Move!
Move!


STOP!

Move! 
Move! 
Move! 

STOP!

[Drop]
I am the Dance Commander!
Surrender your body!
I am the Dance Commander!
Breaking the floor!


Move!
Move!
Move!


STOP!

Move! 
Move! 
Move! 

STOP!


[Drop]
I am the Dance Commander!
Surrender your body!
I am the Dance Commander!
Breaking the floor!

Move!
Move!
Move!


STOP!

Move! 
Move! 
Move! 

STOP!

[Drop]
Obey the sound
Feel the Rhythm
1-2-3-4

STOP!


Call the doctor, heal the night!
Feel the rhythm, hold on tight!
Rhythm doctor, take control,
Pump the bass and heal my soul!

Check the pulse, feel the heat,
The doctor is in, and he’s rocking the street.
No prescription, no delay,
We let the bassline clear the way.
One for the treble, two for the bass,
The rhythm doctor is in the place.
A lyrical healing, deep inside,
Open your mind, let the music collide!

[Pre-Chorus]
Can you feel the power? (Yeah!)
Moving every hour! (Get up!)
The medicine is pumping through your veins...

[Chorus]
Call the doctor, heal the night!
Feel the rhythm, hold on tight!
Rhythm doctor, take control,
Pump the bass and heal my soul!
Rhythm doctor, can't you see?
This is my reality!

[Verse 2]
Diagnosis: Party time!
The rhythm is heavy, the rhythm is prime.
From the front to the very back,
The doctor is putting the train on the track.
Hypnotized by the digital sound,
Feet on the floor, we are leaving the ground.
No more pressure, no more pain,
The rhythm doctor strikes again!

[Chorus]
Call the doctor, heal the night!
Feel the rhythm, hold on tight!
Rhythm doctor, take control,
Pump the bass and heal my soul!

[Bridge]
Heal my soul... feel the rhythm... 
The doctor is in...

[Chorus]
Call the doctor, heal the night!
Feel the rhythm, hold on tight!
Rhythm doctor, take control,
Pump the bass and heal my soul!


[Intro: Heavy static, a deep distorted hum, distant mechanical clicking]
(Error 2-5...)
(System breach...)

[Verse 1: Low, distorted male voice – almost robotic but aggressive]
The code is bleeding through the concrete walls
Binary shadows dancing in the halls
I see the pixels where the sky should be
A fractured version of reality
Static in my veins, wires in my chest
The ghost in the machine is waking from its rest.

[Pre-Chorus: Massive orchestral brass hits, rising electronic tension]
Zeroes and ones...
Coming undone...
The signal is screaming.

[Chorus: Hard Drift Phonk beat, distorted cowbells, heavy 808 bass]
Glitch in the soul, losing the frame
The architecture's burning, I don't know my name
Re-write the heart, delete the pain
Nothing is real, nothing remains
(Error...)
(25 souls in the void.)

[Bridge: Slowed and reverb, sounds like a broken record]
Disconnect.
Reboot.
The simulation is breaking.
Can you feel the frequency?

[Outro: Fast glitching sounds, fading out into a single clean sine wave]
System failure...
Existence not found.
(This song does not exist...)

[End]


[Bridge 2: Aggressive, fast-paced whisper]
Overload.
Overload.
Re-syncing the core...
NOW!

[Drum Break: Pure percussion, heavy bass rolls]

[Final Drop: Maximum intensity, melodic lead synth joining the cowbells]
Glitch in the soul!
(This song does not exist...)

[Outro: Slowing down, distorted cinematic pads, fading heartbeat]
System... shut... down.