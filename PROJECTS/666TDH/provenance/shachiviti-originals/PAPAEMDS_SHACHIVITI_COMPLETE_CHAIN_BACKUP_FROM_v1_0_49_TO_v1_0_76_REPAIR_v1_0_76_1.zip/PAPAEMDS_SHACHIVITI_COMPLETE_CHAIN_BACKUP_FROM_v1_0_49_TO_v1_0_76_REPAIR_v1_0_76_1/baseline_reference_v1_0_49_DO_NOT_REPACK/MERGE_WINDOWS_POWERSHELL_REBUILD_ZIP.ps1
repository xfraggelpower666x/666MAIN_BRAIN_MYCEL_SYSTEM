$Output = "SHACHIVITI_MANTRA_TRACK_SYSTEM_v1_0_49_QUARANTINED_FULLSYSTEM_REPAIR_BACKUP.zip"
$Parts = @(
    "SHACHIVITI_MANTRA_TRACK_SYSTEM_v1_0_49_QUARANTINED_FULLSYSTEM_REPAIR_BACKUP.zip.part01of08"
    "SHACHIVITI_MANTRA_TRACK_SYSTEM_v1_0_49_QUARANTINED_FULLSYSTEM_REPAIR_BACKUP.zip.part02of08"
    "SHACHIVITI_MANTRA_TRACK_SYSTEM_v1_0_49_QUARANTINED_FULLSYSTEM_REPAIR_BACKUP.zip.part03of08"
    "SHACHIVITI_MANTRA_TRACK_SYSTEM_v1_0_49_QUARANTINED_FULLSYSTEM_REPAIR_BACKUP.zip.part04of08"
    "SHACHIVITI_MANTRA_TRACK_SYSTEM_v1_0_49_QUARANTINED_FULLSYSTEM_REPAIR_BACKUP.zip.part05of08"
    "SHACHIVITI_MANTRA_TRACK_SYSTEM_v1_0_49_QUARANTINED_FULLSYSTEM_REPAIR_BACKUP.zip.part06of08"
    "SHACHIVITI_MANTRA_TRACK_SYSTEM_v1_0_49_QUARANTINED_FULLSYSTEM_REPAIR_BACKUP.zip.part07of08"
    "SHACHIVITI_MANTRA_TRACK_SYSTEM_v1_0_49_QUARANTINED_FULLSYSTEM_REPAIR_BACKUP.zip.part08of08"
)

if (Test-Path $Output) {
    Remove-Item $Output
}

$OutStream = [System.IO.File]::OpenWrite($Output)
try {
    foreach ($Part in $Parts) {
        Write-Host "Adding $Part"
        $InStream = [System.IO.File]::OpenRead($Part)
        try {
            $InStream.CopyTo($OutStream)
        } finally {
            $InStream.Close()
        }
    }
} finally {
    $OutStream.Close()
}

Write-Host ""
Write-Host "Fertig: $Output"
Write-Host "SHA256 pruefen:"
Write-Host "certutil -hashfile $Output SHA256"
