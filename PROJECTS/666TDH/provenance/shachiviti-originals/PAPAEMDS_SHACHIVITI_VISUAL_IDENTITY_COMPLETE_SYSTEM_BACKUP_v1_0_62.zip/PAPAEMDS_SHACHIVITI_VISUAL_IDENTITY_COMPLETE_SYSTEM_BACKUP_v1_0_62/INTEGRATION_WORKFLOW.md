# Integration Workflow v1_0_62

**Created:** 2026-06-17T01:33:29Z

## Mandatory sequence

1. Import new material.
2. Integrate into local registers.
3. Run full system audit including the new material.
4. Auto-repair if blockers exist.
5. Re-audit.
6. Freeze only if clean.
7. Create COMPLETE 666 Backup as MD + ZIP.

## Current imported material

- Visual Identity assets: Family Seal, Creator, StreamCoordinator, Detlef, RadioBotAI, Detlef AI, 666SOUNDsDESIGn AI.
- Current generated target image: `wir_sind_eine_familie.png`.

## Integration routing

- Visual Identity Integration Orchestra coordinates.
- Character Role Separation Orchestra verifies role boundaries.
- Visual Text & Logo Verification Orchestra checks visible text.
- Visual Claim Safety Orchestra reframes lore/claim wording.
- Complete Backup Size Guard blocks delta-only backups.
