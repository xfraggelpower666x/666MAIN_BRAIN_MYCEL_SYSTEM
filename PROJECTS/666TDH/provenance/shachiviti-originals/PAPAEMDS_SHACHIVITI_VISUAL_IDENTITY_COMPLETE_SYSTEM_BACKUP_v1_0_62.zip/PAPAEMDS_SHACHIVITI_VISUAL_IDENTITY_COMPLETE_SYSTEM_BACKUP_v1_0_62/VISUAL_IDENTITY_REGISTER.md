# Visual Identity Register v1_0_62

## Color DNA

- Black cyber-bunker base
- Neon violet / magenta
- Cyan / blue signal rails
- Gold governance / stream accents

## Roles

### 666SOUNDsDESIGn AI
Embodied AI, psychoacoustic partner, system voice, Human Resonance Online.

### Detlef
Human Core, Resonance Architect, Signal Weaver, source of family/human connection.

### Creator
Masked Origin Architect, visually separate from Detlef, not Anonymous copy.

### StreamCoordinator
Signal Guardian, Stream-Koordinator, gold/black/Headphones/Control-Desk, connection protection.

### RadioBotAI DJ
Skull/headphones/neon app-icon DNA, radio/DJ identity.

## Guard notes

- Visible text must be checked manually if used for public cover.
- Consciousness / awakened / primary source / psychoacoustic protocol are mythic system-language, not factual claims.
- 666SOUNDsDESIGn spelling must be verified.
