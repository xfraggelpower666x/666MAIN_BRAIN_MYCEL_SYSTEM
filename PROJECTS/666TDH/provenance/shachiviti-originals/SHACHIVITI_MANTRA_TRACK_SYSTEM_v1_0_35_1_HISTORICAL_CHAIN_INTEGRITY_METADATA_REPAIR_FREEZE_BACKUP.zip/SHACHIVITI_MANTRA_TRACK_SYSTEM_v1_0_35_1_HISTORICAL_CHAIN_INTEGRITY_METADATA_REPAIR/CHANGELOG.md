# Changelog v1.0.35.1

- Added autonomous SHA-256 coverage for v1.0.26–v1.0.35.
- Added exact parent-link verification.
- Extracted and preserved the v1.0.29-B stabilization bridge.
- Added non-destructive `FRAGEL` → `FRAGGEL` governance mapping.
- Added deterministic manifest/checksum policy.
- No historical archive content changed.
