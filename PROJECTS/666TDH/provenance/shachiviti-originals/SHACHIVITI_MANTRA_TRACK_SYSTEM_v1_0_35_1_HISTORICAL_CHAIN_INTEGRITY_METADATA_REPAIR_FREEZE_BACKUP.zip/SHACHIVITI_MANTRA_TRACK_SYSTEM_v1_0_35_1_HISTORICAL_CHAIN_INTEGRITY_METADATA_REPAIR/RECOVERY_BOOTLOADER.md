# Recovery Bootloader v1.0.35.1

1. Verify `SHA256SUMS.txt`.
2. Read `BACKUP_VALIDATION.json`.
3. Use `CHAIN_LEDGER.csv` and `PARENT_LINK_VERIFICATION.csv` to confirm lineage.
4. Load the latest historical package `v1.0.35` as the active historical root.
5. Treat v1.0.29-B as the stabilization bridge between v1.0.29 and v1.0.30.
6. Do not rewrite or rename legacy archives.
7. Apply `FRAGGEL` as the active spelling only in new layers.
8. This package repairs metadata coverage; it does not replace newer SHACHIVITI versions.
