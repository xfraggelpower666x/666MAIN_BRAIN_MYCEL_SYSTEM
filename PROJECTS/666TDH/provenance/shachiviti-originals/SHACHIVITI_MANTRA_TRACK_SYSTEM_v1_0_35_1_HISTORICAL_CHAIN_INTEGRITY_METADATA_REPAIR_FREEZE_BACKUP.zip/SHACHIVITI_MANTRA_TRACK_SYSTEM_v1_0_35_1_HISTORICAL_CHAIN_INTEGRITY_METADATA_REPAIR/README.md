# SHACHIVITI v1.0.35.1 Historical Chain Integrity Metadata Repair

This package repairs checksum and lineage coverage for v1.0.26 through v1.0.35 without changing any historical archive.

## Included
- Ten exact standalone source archives, v1.0.26–v1.0.35
- Exact embedded v1.0.29-B stabilization archive
- Chain ledger
- Parent-link byte verification
- Legacy naming correction map
- Recovery bootloader
- Stable manifest and SHA-256 coverage

## Authority
Historical recovery reference only. It is not the current SHACHIVITI master and does not override later governance or current CODEBOX rules.
