# Legacy Naming Correction Map

## Hard preservation rule
Historical archives and their internal filenames remain byte-for-byte unchanged. Renaming them in place would destroy original hashes and recovery evidence.

## Active spelling

```text
FRAGGEL
Fraggel-Dynastie
Fraggel-DNA
```

## Legacy marker
The v1.0.28 archive contains the historic spelling `FRAGEL` / `Fragel-Dynastie`. This is retained only as a provenance marker. New documentation, outputs and repaired layers must use `FRAGGEL`.
